﻿using Forms.Conexao;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Forms.Model
{
    public class Produto
    {
        public int id_produto { get; set; }
        public string descricao { get; set; }
        public string valor_venda { get; set; }
        public string estoque_atual { get; set; }
        public string estoque_minimo { get; set; }
        public string codigo_barra { get; set; }
        public string unidade { get; set; }
        public int ativo { get; set; }
        public int control_estoque { get; set; }
        public int permite_estoque_negativo { get; set; }
        public int grupo { get; set; }
        public int fornecedor { get; set; }
        public int numero_linha { get; set; }

        public int qtd_vendida { get; set; }

        public Produto()
        {

        }

        public Produto(int id_produto, string descricao, string valor_venda, string estoque_atual, string estoque_minimo, string codigo_barra, string unidade, int ativo)
        {
            this.id_produto = id_produto;
            this.descricao = descricao;
            this.valor_venda = valor_venda;
            this.estoque_atual = estoque_atual;
            this.estoque_minimo = estoque_minimo;
            this.codigo_barra = codigo_barra;
            this.unidade = unidade;
            this.ativo = ativo;
        }

        public static List<Produto> Carrega(string pesquisa = "")
        {
            List<Produto> lista = new List<Produto>();
            var conexao = new Conexao.Conexao();

            string sql = "SELECT * FROM produto ";
            sql += $"WHERE descricao LIKE '%{pesquisa}%'";
            SqlCommand cmd = new SqlCommand(sql, conexao.conn);
            conexao.AbrirConexao();

            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Produto prod = new Produto(int.Parse(dr["id_produto"].ToString()),
                                                       dr["descricao"].ToString().ToUpper(),
                                                       dr["valor_venda"].ToString(),
                                                       dr["estoque_atual"].ToString(),
                                                       dr["estoque_minimo"].ToString(),
                                                       dr["codigo_barra"].ToString(),
                                                       dr["unidade"].ToString(),
                                                       int.Parse(dr["ativo"].ToString()));
                    lista.Add(prod);
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
                MessageBox.Show("Ocorreu um erro !", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexao.FecharConexao();
            }

            return lista;
        }
    }
}
