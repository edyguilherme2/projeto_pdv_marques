﻿using Forms.Conexao;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Forms.Model
{
    public class Funcionario
    {
        public int id_funcionario { get; set; }
        public string nome { get; set; }
        public string senha { get; set; }
        public string email { get; set; }
        public string telefone { get; set; }
        public string foto { get; set; }
        public string sexo { get; set; }
        public int nivel_acesso { get; set; }
        public int status { get; set; }

        public Funcionario(int id_funcionario, string nome, string senha, string email, string telefone, string foto, string sexo, int nivel_acesso,int status)
        {
            this.id_funcionario = id_funcionario;
            this.nome = nome;
            this.senha = senha;
            this.email = email;
            this.telefone = telefone;
            this.foto = foto;
            this.sexo = sexo;
            this.nivel_acesso = nivel_acesso;
            this.status = status;
        }
        public Funcionario()
        {

        }
        public Funcionario(string nome)
        {
            this.nome = nome;
        }

        public Funcionario AddAdmin()
        {
            return new Funcionario(0,"ADMINISTRADOR",Criptografar.CriptografarMD5("123"),"","","","M",0,1);
        }

        public static List<Funcionario> CarregaFuncionarios(string pesquisa = "")
        {
            if (pesquisa == "")
                pesquisa = "%%";
            else
                pesquisa = "%" +pesquisa + "%";

            List<Funcionario> lista = new List<Funcionario>();
            var conexao = new Conexao.Conexao();

            string sql = "SELECT * FROM funcionario WHERE nome LIKE @pesquisa AND status = 1";

            SqlCommand cmd = new SqlCommand(sql, conexao.conn);
            cmd.Parameters.AddWithValue("@pesquisa", pesquisa);
            conexao.AbrirConexao();

            lista = new List<Funcionario>();
            Funcionario f = new Funcionario("ADMINISTRADOR");
            lista.Add(f.AddAdmin());

            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Funcionario func = new Funcionario(int.Parse(dr["id_funcionario"].ToString()),
                                                       dr["nome"].ToString().ToUpper(),
                                                       dr["senha"].ToString(),
                                                       dr["email"].ToString(),
                                                       dr["telefone"].ToString(),
                                                       dr["foto"] == DBNull.Value ? "" : dr["foto"].ToString(),
                                                       dr["sexo"].ToString(),
                                                       int.Parse(dr["nivel_acesso"].ToString()),
                                                       dr["status"] == DBNull.Value ? 0 : int.Parse(dr["status"].ToString()));
                    lista.Add(func);
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
                MessageBox.Show("Ocorreu um erro !", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexao.FecharConexao();
            }

            return lista;
        }
    }
}
