﻿namespace Forms.Model
{
    public static class DadosLogin
    {
        public static string id_funcionario { get; set; }
        public static string nome { get; set; }
        public static string sexo { get; set; }
        public static int nivel_acesso { get; set; }
    }
}
