﻿using System;
using System.Data.SqlClient;

namespace Forms.Conexao
{
    internal class Conexao
    {
        
        private readonly string banco = "INTERCAMBIO";
        //private readonly string source = $"{Environment.MachineName}\\SQLEXPRESS";
        private readonly string source = $"{Environment.MachineName}\\SQLEXPRESS";
        public readonly SqlConnection conn;
    
        public Conexao()
        {
            conn = new SqlConnection($"Data Source={source};Initial Catalog={banco}; Integrated Security=true");
        }

        public void AbrirConexao()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();
        }

        public void FecharConexao()
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }
}
