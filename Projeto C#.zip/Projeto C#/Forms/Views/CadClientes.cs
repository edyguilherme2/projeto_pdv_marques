﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms
{
    public partial class CadClientes : Form
    {
        public CadClientes()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Text = "Programa 1";
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tbNome.Select();
            if(tbNome.Text == "" && tbEmail.Text == "" && tbCidade.Text == "" && tbEndereco.Text == "" && tbTelefone.Text == "")
                MessageBox.Show("Nenhum campo foi preenchido !", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Stop); 
            else
                MessageBox.Show("Cadastrado com sucesso !", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //CARREGAR UMA IMAGEM
            openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            openFileDialog1.FileName = "openFileDialog1";
            var teste = openFileDialog1;
            DialogResult dr = openFileDialog1.ShowDialog();

            if (dr == DialogResult.OK)
            {
                Image Imagem = Image.FromFile(openFileDialog1.FileName);
                pictureBox1.Image = Imagem;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        void Limpar()
        {
            tbNome.Clear();
            tbTelefone.Clear();
            tbEmail.Clear();
            tbEndereco.Clear();
            tbCidade.Clear();
            rbF.Checked = false;
            rbM.Checked = false;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            Limpar();
        }
    }
}
