﻿using Forms.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace Forms.Views
{
    public partial class frmFinalizarVenda : Form
    {
        List<Produto> produtos = new List<Produto>();
        public frmFinalizarVenda(List<Produto> carrinho)
        {
            InitializeComponent();
            produtos = carrinho;
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            if(tbFormaPagamento.Text == "")
            {
                tbFormaPagamento.Select();
                return;
            }
            gravarVenda();
            Close();
        }

        //GRAVAR VENDA NO BANCO
        private int RegistrarVenda()
        {
            string id_forma_pagamento = tbFormaPagamento.Text;
            string parcelas = tbParcelas.Text;
            string total = tbValorTotal.Text;
            string desconto = tbValorDesconto.Text;

            var conexao = new Conexao.Conexao();
            try
            {
                string sql = @"INSERT INTO venda (id_cliente, id_funcionario, valor_total, desconto, id_forma_pagamento,data_venda)
                               VALUES(@id_cliente, @id_funcionario, @valor_total, @desconto, @id_forma_pagamento, @data_venda)";
                
                SqlCommand cmd = new SqlCommand(sql, conexao.conn);
                
                cmd.Parameters.AddWithValue("@id_cliente", 0);
                cmd.Parameters.AddWithValue("@id_funcionario", (DadosLogin.id_funcionario == null || DadosLogin.id_funcionario == "" ? 0 : int.Parse(DadosLogin.id_funcionario)));
                cmd.Parameters.AddWithValue("@valor_total",decimal.Parse(total));
                cmd.Parameters.AddWithValue("@desconto", decimal.Parse(desconto));
                cmd.Parameters.AddWithValue("@id_forma_pagamento", int.Parse(id_forma_pagamento));
                cmd.Parameters.AddWithValue("@data_venda", DateTime.Now.ToShortDateString());

                conexao.AbrirConexao();

                cmd.ExecuteNonQuery();
                //MessageBox.Show("Venda gravada com sucesso !", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                Console.Write(ex.ToString());
            }
            finally
            {
                conexao.FecharConexao();
            }

            return GetUltimaVenda();
        }

        private void RegistrarVendaItem(int id_venda, Produto p)
        {
            var conexao = new Conexao.Conexao();
            try
            {
                string sql = @"INSERT INTO venda_item (id_venda, id_produto, quantidade, valor_item, valor_total, data)
                               VALUES(@id_venda, @id_produto, @quantidade, @valor_item, @valor_total, @data)";

                SqlCommand cmd = new SqlCommand(sql, conexao.conn);

                cmd.Parameters.AddWithValue("@id_venda", id_venda);
                cmd.Parameters.AddWithValue("@id_produto", p.id_produto);
                cmd.Parameters.AddWithValue("@quantidade", p.qtd_vendida);
                cmd.Parameters.AddWithValue("@valor_item", decimal.Parse(p.valor_venda));
                cmd.Parameters.AddWithValue("@valor_total", decimal.Parse(p.valor_venda) * p.qtd_vendida);
                cmd.Parameters.AddWithValue("@data", DateTime.Now.ToShortDateString());

                conexao.AbrirConexao();

                cmd.ExecuteNonQuery();
                //MessageBox.Show("Venda gravada com sucesso !", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
            finally
            {
                conexao.FecharConexao();
            }
        }

        //SELECT PARA RETORNAR O ID DA ULTIMA VENDA
        private int GetUltimaVenda()
        {
            int id = 0;
            var conexao = new Conexao.Conexao();

            string sql = "SELECT MAX(id_venda) AS id_venda FROM venda ORDER BY id_venda DESC";
            SqlCommand cmd = new SqlCommand(sql, conexao.conn);
            conexao.AbrirConexao();

            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                    id = int.Parse(dr["id_venda"].ToString());                    
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
                MessageBox.Show("Ocorreu um erro !", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexao.FecharConexao();
            }

            return id;
        }

        private void gravarVenda()
        {
            //GRAVAR VENDA
            //PEGAR ID DA VENDA
            int id = RegistrarVenda();

            foreach(var item in produtos)
            {
                //GRAVAR ITENS PASSANDO ID DA VENDA;
                RegistrarVendaItem(id, item);
            }

            //MOSTRAR MENSAGEM DE GRAVADO COM SUCESSO !
            if (id > 0)
                MessageBox.Show("Venda Gravada com sucesso !");
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmFinalizarVenda_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
                btnConfirmar_Click(sender, e);
            if (e.KeyCode == Keys.Escape)
                btnCancelar_Click(sender, e);
        }

        private void frmFinalizarVenda_Load(object sender, EventArgs e)
        {
            tbFormaPagamento.Select();

            carregaFormaPagamento();

            var total = produtos.Sum(x => decimal.Parse(x.valor_venda) * x.qtd_vendida);
            tbValorTotal.Text = total.ToString();
        }

        private void carregaFormaPagamento()
        {
            listView1.Items.Clear();
            var lvw = new ListViewItem();
            var descricao = new ListViewItem.ListViewSubItem();
            lvw.Text = "1";
            descricao.Text = "DINHEIRO";
            lvw.SubItems.Add(descricao);
            listView1.Items.Add(lvw);
            lvw = new ListViewItem();
            descricao = new ListViewItem.ListViewSubItem();
            lvw.Text = "2";
            descricao.Text = "CARTÃO DE DEBITO";
            lvw.SubItems.Add(descricao);
            listView1.Items.Add(lvw);
            lvw = new ListViewItem();
            descricao = new ListViewItem.ListViewSubItem();
            lvw.Text = "3";
            descricao.Text = "CARTÃO DE CRÉDITO";
            lvw.SubItems.Add(descricao);
            listView1.Items.Add(lvw);
            lvw = new ListViewItem();
            descricao = new ListViewItem.ListViewSubItem();
            lvw.Text = "4";
            descricao.Text = "PIX";
            lvw.SubItems.Add(descricao);
            listView1.Items.Add(lvw);
        }

            private void tbFormaPagamento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                tbParcelas.Select();
        }

        private void tbParcelas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                tbValorDesconto.Select();
        }

        private void tbValorDesconto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                tbValorReceber.Select();
        }

        private void tbValorReceber_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                tbTroco.Select();
        }

        private void tbValorTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void tbValorTotal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnConfirmar_Click(sender, e);
        }

        private void tbTroco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                tbValorTotal.Select();
        }

        private void tbValorDesconto_Leave(object sender, EventArgs e)
        {
            if (tbTroco.Text == "" || tbTroco.Text == "0")
            {
                //tbValorTotal.Text = tbValorReceber.Text;
            }
        }

        private void tbValorReceber_Leave(object sender, EventArgs e)
        {
            if (tbValorReceber.Text != "")
            {
                tbTroco.Text = (decimal.Parse(tbValorReceber.Text) - decimal.Parse(tbValorTotal.Text)).ToString("n");
            }

        }
    }
}
