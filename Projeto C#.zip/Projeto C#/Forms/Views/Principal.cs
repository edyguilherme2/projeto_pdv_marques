﻿using Forms.Model;
using Forms.Views;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Forms
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            new CadClientes().ShowDialog();
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            //CHAMA TELA DE LOGIN
            login();
            var funcionarios = Funcionario.CarregaFuncionarios();
            var produtos = Produto.Carrega();
            lbTotalFuncionarios.Text = funcionarios.Count.ToString();
            lbTotalProdutos.Text = produtos.Count.ToString();
            
            GetTotalVendasAtivas();
        }

        private void GetTotalVendasAtivas()
        {
            var conexao = new Conexao.Conexao();

            string sql = @"SELECT * FROM venda";

            SqlCommand cmd = new SqlCommand(sql, conexao.conn);
            conexao.AbrirConexao();

            try
            {
                int i = 0;
                decimal total = 0;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    i++;
                    total += decimal.Parse(dr["valor_total"].ToString());
                }
                lbTotalVendas.Text = i.ToString();
                lbTotalTicketMedio.Text = (total / i).ToString("n");
                lbValorTotalVendas.Text = total.ToString("n");
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
                //MessageBox.Show("Ocorreu um erro !", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexao.FecharConexao();
            }
        }

        private void fecharToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var a = MessageBox.Show("Tem Certeja que deseja encerrar ?", "Pergunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (a.ToString().ToUpper() == "YES")
               Application.Exit();
        }

        private void cadastrarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new ConsultaClientes().ShowDialog();
        }

        private void novoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CadClientes().ShowDialog();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            //tela cadastro produto
            new CadProduto().ShowDialog();
        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //tela consulta produto
            new ConsultaProdutos().ShowDialog();
        }

        private void novoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //tela novo funcionario
            new CadFuncionario().ShowDialog();
        }

        private void consultarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //tela novo funcionario
            new ConsultaFuncionarios().ShowDialog();
        }

        public void login()
        {
            this.Hide();
            Login frmLogin = new Login(DadosLogin.nome, DadosLogin.nivel_acesso, DadosLogin.sexo);
            
            frmLogin.ShowDialog();
            lbBoasVindas.Text = DadosLogin.sexo == "F" ? ("BEM VINDA : " + DadosLogin.nome) : ("BEM VINDO : " + DadosLogin.nome);

            if (DadosLogin.nome == null || DadosLogin.nome == "")
            {
                DadosLogin.nome = "Anônimo";
                DadosLogin.sexo = "F";
            }

            frmLogin.Close();
        }

        private void trocarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login frmLogin = new Login("",0,"");
            frmLogin.ShowDialog();
            try
            {
                this.Show();
            }
            catch(Exception ex){

            }
            
            lbBoasVindas.Text = DadosLogin.sexo == "F" ? ("BEM VINDA : " + DadosLogin.nome) : ("BEM VINDO : " + DadosLogin.nome);
            frmLogin.Close();
        }

        private void funcionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void relatóriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //RELATOROIO PRODUTOS MAIS VENDIDOS
        }

        private void vendasPorDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //RELATORIO VENDA

        }

        private void auditoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Auditoria
        }

        private void acessosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ACESSOS
        }

        private void pDVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new PDV().ShowDialog();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Dashboard_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.F12)
                new PDV().ShowDialog();
            if (e.KeyCode == Keys.Escape)
                Close();
        }
    }
}
