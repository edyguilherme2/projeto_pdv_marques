﻿namespace Forms.Views
{
    partial class frmConsultaVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView1 = new System.Windows.Forms.ListView();
            this.codigo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.data = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.funcionario = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.valor_Ttal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.desconto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.recebito = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lbTotalRegistros = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbDataInicial = new System.Windows.Forms.DateTimePicker();
            this.tbDataFinal = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.troco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cancelado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.codigo,
            this.data,
            this.funcionario,
            this.valor_Ttal,
            this.desconto,
            this.recebito,
            this.troco,
            this.cancelado});
            this.listView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.LabelWrap = false;
            this.listView1.Location = new System.Drawing.Point(14, 51);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(776, 340);
            this.listView1.TabIndex = 32;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // codigo
            // 
            this.codigo.Text = "";
            this.codigo.Width = 0;
            // 
            // data
            // 
            this.data.Text = "Data";
            this.data.Width = 100;
            // 
            // funcionario
            // 
            this.funcionario.Text = "Funcionario";
            this.funcionario.Width = 190;
            // 
            // valor_Ttal
            // 
            this.valor_Ttal.Text = "Valor Total";
            this.valor_Ttal.Width = 100;
            // 
            // desconto
            // 
            this.desconto.Text = "Desconto";
            this.desconto.Width = 100;
            // 
            // recebito
            // 
            this.recebito.Text = "Valor Recebido";
            this.recebito.Width = 100;
            // 
            // lbTotalRegistros
            // 
            this.lbTotalRegistros.AutoSize = true;
            this.lbTotalRegistros.Location = new System.Drawing.Point(90, 394);
            this.lbTotalRegistros.Name = "lbTotalRegistros";
            this.lbTotalRegistros.Size = new System.Drawing.Size(19, 13);
            this.lbTotalRegistros.TabIndex = 31;
            this.lbTotalRegistros.Text = "00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 394);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 30;
            this.label5.Text = "Total Registros:";
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(690, 19);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(100, 24);
            this.btnPesquisar.TabIndex = 28;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(433, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "Data Inicial";
            // 
            // tbDataInicial
            // 
            this.tbDataInicial.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.tbDataInicial.Location = new System.Drawing.Point(436, 24);
            this.tbDataInicial.Name = "tbDataInicial";
            this.tbDataInicial.Size = new System.Drawing.Size(107, 20);
            this.tbDataInicial.TabIndex = 33;
            this.tbDataInicial.Value = new System.DateTime(2023, 6, 26, 0, 0, 0, 0);
            // 
            // tbDataFinal
            // 
            this.tbDataFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.tbDataFinal.Location = new System.Drawing.Point(565, 23);
            this.tbDataFinal.Name = "tbDataFinal";
            this.tbDataFinal.Size = new System.Drawing.Size(107, 20);
            this.tbDataFinal.TabIndex = 35;
            this.tbDataFinal.Value = new System.DateTime(2023, 6, 26, 0, 0, 0, 0);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(562, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Data Final";
            // 
            // troco
            // 
            this.troco.Text = "Troco";
            // 
            // cancelado
            // 
            this.cancelado.Text = "Cancelada";
            this.cancelado.Width = 70;
            // 
            // frmConsultaVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 410);
            this.Controls.Add(this.tbDataFinal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbDataInicial);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.lbTotalRegistros);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.label1);
            this.Name = "frmConsultaVenda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vendas Realizadas";
            this.Load += new System.EventHandler(this.frmConsultaVenda_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader codigo;
        private System.Windows.Forms.ColumnHeader data;
        private System.Windows.Forms.ColumnHeader funcionario;
        private System.Windows.Forms.ColumnHeader valor_Ttal;
        private System.Windows.Forms.ColumnHeader desconto;
        private System.Windows.Forms.ColumnHeader recebito;
        private System.Windows.Forms.Label lbTotalRegistros;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker tbDataInicial;
        private System.Windows.Forms.DateTimePicker tbDataFinal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ColumnHeader troco;
        private System.Windows.Forms.ColumnHeader cancelado;
    }
}