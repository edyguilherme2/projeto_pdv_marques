﻿using Forms.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Forms.Views
{
    public partial class PDV : Form
    {
        Produto produto_selecionado = new Produto();
        List<Produto> carrinho = new List<Produto>();
        int total_linhas = 1;

        public PDV()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            selecionarProduto();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            //Tem certeza que deseja fechar
            Close();
        }

        private void selecionarProduto()
        {
            if (tbProduto.Text == "")
            {
                var form = new ConsultaProdutos();
                form.ShowDialog();
                var produto = form.produto;
                //CHAMA TELA CONSULTA PRODUTOS
                //MessageBox.Show(produto.descricao);

                if (produto.id_produto == 0)
                    return;

                if (produto.control_estoque == 1 && produto.estoque_atual != null && int.Parse(produto.estoque_atual) <= 0)
                {
                    MessageBox.Show("PRODUTO COM ESTOQUE ZERADO");
                }
                else
                {
                    produto_selecionado = produto;
                    tbProduto.Text = produto.descricao;
                    LbProduto.Text = produto.descricao;
                    LBValor.Text = produto.valor_venda;
                    tbQuantidade.Select();
                }
            }
            
        }

        private void tbProduto_KeyDown(object sender, KeyEventArgs e)
        {
            selecionarProduto();
        }

        private void tbQuantidade_KeyDown(object sender, KeyEventArgs e)
        {
            Adicionar();
        }

        private void tbDesconto_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Adicionar()
        {
            if (tbQuantidade.Text == "" || tbQuantidade.Text == "0" || int.Parse(tbQuantidade.Text) < 0) {
                tbQuantidade.Text = "";
                tbQuantidade.Select();
                return;
            }

            decimal valor_total = 0;
            var lvw = new ListViewItem();
            var descricao = new ListViewItem.ListViewSubItem();
            var quantidade = new ListViewItem.ListViewSubItem();
            var valor_produto = new ListViewItem.ListViewSubItem();
            
            lvw.Text = total_linhas.ToString();
            
            descricao.Text = tbProduto.Text;
            quantidade.Text = tbQuantidade.Text;
            if (tbQuantidade.Text == "")
                tbQuantidade.Text = "1";

            valor_total = decimal.Parse(produto_selecionado.valor_venda) * decimal.Parse(tbQuantidade.Text);

            valor_produto.Text = valor_total.ToString();
           
            lvw.SubItems.Add(descricao);
            lvw.SubItems.Add(quantidade);
            lvw.SubItems.Add(valor_produto);

            listView1.Items.Add(lvw);

            lbValorTotal.Text = (decimal.Parse(lbValorTotal.Text.Replace("R$ ","")) + valor_total).ToString();

            produto_selecionado.qtd_vendida = int.Parse(tbQuantidade.Text);
            //produto_selecionado.estoque_atual = tbQuantidade.Text;
            //produto_selecionado.valor_venda = (decimal.Parse(tbQuantidade.Text) * decimal.Parse(lbValorTotal.Text)).ToString();
            produto_selecionado.numero_linha = total_linhas;

            carrinho.Add(produto_selecionado);

            PintarLinhaLvw(ref listView1);
            LBValor.Text = LbProduto.Text =  tbProduto.Text = tbQuantidade.Text = "";

            tbQuantidade.Text = "1";
            tbProduto.Select();
            total_linhas++;
        }

        private void PintarLinhaLvw(ref ListView lv)
        {
            if (lv.Items.Count > 0)
                if ((lv.Items.Count - 1) % 2 == 0)
                    lv.Items[lv.Items.Count - 1].BackColor = Color.FromArgb(238, 238, 238);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            hora.Text = DateTime.Now.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //ABRIR MODAL FINALIZAR VENDA
            var form = new frmFinalizarVenda(carrinho);
            form.ShowDialog();

            lbValorTotal.Text = "R$ 0,00";
            carrinho = new List<Produto>();

            listView1.Clear();
        }

        private void PDV_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                Close();
            //if (e.KeyCode == Keys.F10)
                //new frmFinalizarVenda().ShowDialog();
        }

        private void tbProduto_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                Close();
            if(e.KeyCode == Keys.Space)
                selecionarProduto();
            if (e.KeyCode == Keys.F10)
                button2_Click(sender, e);
            if (e.KeyCode == Keys.F6)
                button4_Click(sender, e);
        }

        private void PDV_Load(object sender, EventArgs e)
        {
            lbNomeFuncionario.Text = DadosLogin.nome.ToUpper();
            
            tbProduto.Select();
        }

        private void tbQuantidade_KeyDown_1(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
                Adicionar();
            if (e.KeyCode == Keys.F6)
                Limpar();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        //LIMPAR DADOS DA TELA DO PDV
        private void Limpar()
        {
            listView1.Clear();
            LBValor.Text = LbProduto.Text = tbProduto.Text = tbQuantidade.Text = "";
            lbValorTotal.Text = "R$ 0,00";
            tbQuantidade.Text = "1";
            tbProduto.Select();
        }

        private void tbQuantidade_Leave(object sender, EventArgs e)
        {
            
        }

        private void tbQuantidade_KeyUp(object sender, KeyEventArgs e)
        {
            tbQuantidade.Text = tbQuantidade.Text.Replace("-", "").Replace("+", "");
        }

        private void btnConsultarVenda_Click(object sender, EventArgs e)
        {
            //CHAMAR FORM CONSULTA VENDAS
            var frm = new frmConsultaVenda();
            frm.ShowDialog();
        }
    }
}
