﻿using Forms.Conexao;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Forms.Views
{
    public partial class CadFuncionario : Form
    {
        int id_funcionario;

        public CadFuncionario()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (id_funcionario != null && id_funcionario > 0)
                Alterar();
            else
               Gravar();
        }

        private void Alterar()
        {
            string sql = @"UPDATE funcionario set nome = @nome, email = @email, telefone = @telefone WHERE id_funcionario = @id_funcionario";
            var conexao = new Conexao.Conexao();
            SqlCommand cmd = new SqlCommand(sql, conexao.conn);

            try
            {
                cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                cmd.Parameters.AddWithValue("@telefone", tbTel.Text);
                cmd.Parameters.AddWithValue("@id_funcionario", id_funcionario);

                conexao.AbrirConexao();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Alterado com sucesso!");
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
            finally
            {
                conexao.FecharConexao();
            }
        }

        private void Gravar()
        {
            string sql = @"INSERT INTO funcionario (nome,email,telefone,senha,nivel_acesso,sexo,foto)
                               VALUES(@nome,@email,@telefone,@senha,@nivel_acesso,@sexo,@foto)";
            var conexao = new Conexao.Conexao();
            SqlCommand cmd = new SqlCommand(sql, conexao.conn);

            try
            {
                cmd.Parameters.AddWithValue("@nome", tbNome.Text.ToUpper());
                cmd.Parameters.AddWithValue("@email", tbEmail.Text.ToUpper());
                cmd.Parameters.AddWithValue("@telefone", tbTel.Text);
                cmd.Parameters.AddWithValue("@senha", Criptografar.CriptografarMD5(tbSenha.Text.ToUpper()));
                cmd.Parameters.AddWithValue("@nivel_acesso", cbNivel.SelectedIndex);
                cmd.Parameters.AddWithValue("@sexo", rbF.Checked ? "F": rbM.Checked ? "M":"");
                cmd.Parameters.AddWithValue("@foto", DBNull.Value);
                
                conexao.AbrirConexao();
                    
                cmd.ExecuteNonQuery();
                MessageBox.Show("Gravado com sucesso !", "Sucesso",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocorreu um erro,"+ex, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexao.FecharConexao();
            }
        }

        private void CadFuncionario_Load(object sender, EventArgs e)
        {
            var frm = new ConsultaFuncionarios();
            frm.ShowDialog();
            var id = frm.id_funcionario_selecionado;
            if (frm.id_funcionario_selecionado != null || frm.id_funcionario_selecionado != 0)
                Carrega(frm.id_funcionario_selecionado);

            tbNome.Select();
        }

        private void Carrega(int id)
        {
            var conexao = new Conexao.Conexao();

            string sql = "SELECT * FROM funcionario WHERE id_funcionario = "+id;

            SqlCommand cmd = new SqlCommand(sql, conexao.conn);
            conexao.AbrirConexao();
            
            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    id_funcionario = int.Parse(dr["id_funcionario"].ToString());
                    tbNome.Text = dr["nome"].ToString();
                    tbEmail.Text = dr["email"].ToString();
                    tbTel.Text = dr["telefone"].ToString();
                    if (dr["sexo"].ToString() == "M")
                        rbM.Checked = true;
                    else
                        rbF.Checked = true;

                    
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Excluir();
            //Excluir();
        }

        private void Excluir()
        {
            string sql = @"UPDATE funcionario set status = 0 WHERE id_funcionario = @id_funcionario";
            var conexao = new Conexao.Conexao();
            SqlCommand cmd = new SqlCommand(sql, conexao.conn);

            try
            {
                cmd.Parameters.AddWithValue("@id_funcionario", id_funcionario );
                conexao.AbrirConexao();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Excluido com sucesso!");
            }
            catch(Exception ex)
            {
                Console.Write(ex.ToString());
            }
            finally
            {
                conexao.FecharConexao();
            }
        }

        private void limpar()
        {
            tbNome.Clear();
            tbEmail.Clear();
            tbTel.Clear();
            tbSenha.Clear();
            cbNivel.SelectedIndex = 0;
            rbF.Checked = rbM.Checked = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            var frm = new ConsultaFuncionarios();
            frm.ShowDialog();
            var id = frm.id_funcionario_selecionado;
            if (frm.id_funcionario_selecionado != null || frm.id_funcionario_selecionado != 0)
                Carrega(frm.id_funcionario_selecionado);

            tbNome.Select();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        private void Limpar()
        {
            tbNome.Text =
                tbEmail.Text =
                    tbSenha.Text =
                        tbTel.Text =
                            tbSenha.Text = "";
            cbNivel.SelectedIndex = 0;
            rbF.Checked = rbM.Checked = false;
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            btnAlterar.Enabled = false;
            //btnNovo.Enabled = false;
            //btnExcluir.Enabled = false;
        }
    }
}
