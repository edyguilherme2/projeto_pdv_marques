﻿using Forms.Model;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Forms.Views
{
    public partial class ConsultaClientes : Form
    {
        public ConsultaClientes()
        {
            InitializeComponent();
        }

        private void ConsultaClientes_Load(object sender, EventArgs e)
        {
            Carregar();
            tbNome.Focus();            
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            Carregar();
        }

        private void Carregar()
        {
            ///List<Funcionario> lista = Funcionario.CarregaFuncionarios();
            //foreach(var func in lista)
        }
    }
}
