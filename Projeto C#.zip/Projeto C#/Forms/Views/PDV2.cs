﻿using System;
using System.Windows.Forms;

namespace Forms.Views
{
    public partial class PDV : Form
    {
        public PDV()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            //Tem certeza que deseja fechar
            Close();
        }

        private void tbProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Space && tbProduto.Text == "")
            {
                var form = new ConsultaProdutos();
                form.ShowDialog();
                var produto = form.produto;
                //CHAMA TELA CONSULTA PRODUTOS
                MessageBox.Show(produto.descricao);
            }
            else if(e.KeyCode == Keys.Escape)
            {
                Close();
            }
        }

        private void tbDesconto_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void tbQuantidade_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
