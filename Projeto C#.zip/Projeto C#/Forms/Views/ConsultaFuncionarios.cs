﻿using Forms.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Forms.Views
{
    public partial class ConsultaFuncionarios : Form
    {
        public int id_funcionario_selecionado = 0;

        public ConsultaFuncionarios()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            Carregar(tbPesquisa.Text);
        }

        private void ConsultaFuncionarios_Load(object sender, EventArgs e)
        {
            Carregar(tbPesquisa.Text);
            tbPesquisa.Focus();
        }

        private void tbNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                Close();
        }

        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            Carregar(tbPesquisa.Text);
        }

        private void Carregar(string pesquisa = "")
        {
            listView1.Items.Clear();
            List<Funcionario> lista = Funcionario.CarregaFuncionarios(pesquisa);
            foreach (var item in lista)
            {
                var lvw = new ListViewItem();
                var nome = new ListViewItem.ListViewSubItem();
                var email = new ListViewItem.ListViewSubItem();
                var telefone = new ListViewItem.ListViewSubItem();
                var sexo = new ListViewItem.ListViewSubItem();
                var nivel_acesso = new ListViewItem.ListViewSubItem();
                var ativo = new ListViewItem.ListViewSubItem();

                ativo.Text = item.status == 1 ? "ATIVO" : "INATIVO";

                lvw.Text = $"{item.id_funcionario:D4}";
                nome.Text = item.nome;
                email.Text = item.email;
                sexo.Text = item.sexo == "M" ? "MASCULINO" : "FEMININO";
                telefone.Text = item.telefone;

                if (item.nivel_acesso == 0)
                    nivel_acesso.Text = "Administrador";
                else if (item.nivel_acesso == 1)
                    nivel_acesso.Text = "Gerência";
                else if (item.nivel_acesso == 2)
                    nivel_acesso.Text = "Estoque";
                else if (item.nivel_acesso == 3)
                    nivel_acesso.Text = "Vendedor";
                else if (item.nivel_acesso == 4)
                    nivel_acesso.Text = "Atendente";

                lvw.SubItems.Add(nome);
                lvw.SubItems.Add(email);
                lvw.SubItems.Add(telefone);
                lvw.SubItems.Add(sexo);
                lvw.SubItems.Add(nivel_acesso);
                lvw.SubItems.Add(ativo);

                listView1.Items.Add(lvw);

                PintarLinhaLvw(ref listView1);
            }
            lbTotal.Text = (lista.Count).ToString("D4");
        }

        private void PintarLinhaLvw(ref ListView lv)
        {
            if (lv.Items.Count > 0)
                if ((lv.Items.Count - 1) % 2 == 0)
                    lv.Items[lv.Items.Count - 1].BackColor = Color.FromArgb(238, 238, 238);
        }


        private void tbPesquisa_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Carregar(tbPesquisa.Text);
            }
            else if (e.KeyCode == Keys.Escape)
                Close();
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                id_funcionario_selecionado = int.Parse(listView1.SelectedItems[0].Text);

                Close();
            }
        }
    }
}
