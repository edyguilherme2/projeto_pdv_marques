﻿using Forms.Conexao;
using Forms.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Forms
{
    public partial class Login : Form
    {
        List<Funcionario> lista = new List<Funcionario>();
        bool login = false;

        public Login(string nome, int nivel_acesso, string sexo)
        {
            InitializeComponent();
            DadosLogin.nome = nome;
            DadosLogin.sexo = sexo;
            DadosLogin.nivel_acesso = nivel_acesso;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ValidaLogin();
        }

        private void tbSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
                ValidaLogin();
        }

        public void ValidaLogin()
        {           
            foreach(var func in lista)
                if(cbLogin.Text.ToUpper() == func.nome && func.senha == Criptografar.CriptografarMD5(tbSenha.Text))
                {
                    DadosLogin.nome = func.nome;
                    DadosLogin.nivel_acesso = func.nivel_acesso;
                    DadosLogin.sexo = func.sexo;
                    login = true;
                    
                }
            
            if(!login)
                MessageBox.Show("Senha Inválida", "Erro !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            if (login)
                this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var a = MessageBox.Show("Tem Certeja que deseja encerrar ?", "Pergunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (a.ToString().ToUpper() == "YES")
                Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Login_Load(object sender, EventArgs e)
        {
            lista = Funcionario.CarregaFuncionarios();
            foreach(var func in lista)
                cbLogin.Items.Add(func.nome);

            cbLogin.SelectedIndex = 0;
            tbSenha.Select();
        }

        private void cbLogin_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbSenha.Focus();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
