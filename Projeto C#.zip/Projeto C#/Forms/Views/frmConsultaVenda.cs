﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms.Views
{
    public partial class frmConsultaVenda : Form
    {
        public frmConsultaVenda()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {

        }

        private void frmConsultaVenda_Load(object sender, EventArgs e)
        {
            ConsultaVendas("","");
        }

        private void ConsultaVendas(string dt_inicial, string dt_final)
        {
            var conexao = new Conexao.Conexao();

            string sql = @"SELECT venda.*, funcionario.nome FROM venda
                           INNER JOIN funcionario ON
                           funcionario.id_funcionario = venda.id_funcionario ";
            
            SqlCommand cmd = new SqlCommand(sql, conexao.conn);
            //cmd.Parameters.AddWithValue("data_incial", dt_inicial);
            //cmd.Parameters.AddWithValue("data_final", dt_final);
            conexao.AbrirConexao();

            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    var lvw = new ListViewItem();
                    var data = new ListViewItem.ListViewSubItem();
                    var func = new ListViewItem.ListViewSubItem();
                    var total = new ListViewItem.ListViewSubItem();
                    var desconto = new ListViewItem.ListViewSubItem();
                    var recebido = new ListViewItem.ListViewSubItem();
                    var cancelado = new ListViewItem.ListViewSubItem();
                    var troco = new ListViewItem.ListViewSubItem();

                    lvw.Text = dr["id_venda"].ToString();
                    data.Text = dr["data_venda"].ToString();
                    func.Text = dr["nome"].ToString().ToUpper();
                    desconto.Text = dr["desconto"].ToString();
                    total.Text = dr["valor_total"].ToString();
                    recebido.Text = "";
                    troco.Text = "";
                    cancelado.Text = "NAO";

                    lvw.SubItems.Add(data);
                    lvw.SubItems.Add(func);
                    lvw.SubItems.Add(total);
                    lvw.SubItems.Add(desconto);
                    lvw.SubItems.Add(recebido);
                    lvw.SubItems.Add(troco);
                    lvw.SubItems.Add(cancelado);

                    //lvw.SubItems.Add(status);

                    listView1.Items.Add(lvw);

                    PintarLinhaLvw(ref listView1);
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
                //MessageBox.Show("Ocorreu um erro !", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexao.FecharConexao();
            }
        }

        private void PintarLinhaLvw(ref ListView lv)
        {
            if (lv.Items.Count > 0)
                if ((lv.Items.Count - 1) % 2 == 0)
                    lv.Items[lv.Items.Count - 1].BackColor = Color.FromArgb(238, 238, 238);
        }

    }
}
