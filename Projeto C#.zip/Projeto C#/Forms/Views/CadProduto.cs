﻿using Forms.Conexao;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Forms.Views
{
    public partial class CadProduto : Form
    {
        public CadProduto()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            //btnNovo
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            //btnAlterar
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            //btnGravar

            if (ValidaCampos())
            {
                Gravar();
                LimparCampos();
            }
        }

        private bool ValidaCampos()
        {
            bool valido = true;

            if(tbDescricao.Text == "")
            {
                MessageBox.Show("Prencha o campo descrição!");
                tbDescricao.Focus();
                return false;
            }

            if (tbValorVenda.Text == "")
            {
                MessageBox.Show("Prencha o campo valor venda!");
                tbValorVenda.Focus();
                return false;
            }

            return valido;
        }

        private void LimparCampos()
        {
            tbDescricao.Text =
                tbCodigoBarra.Text =
                    tbValorVenda.Text =
                        tbEstoque.Text =
                            tbEstoqueMinimo.Text = "";
            chControlaEstoque.Checked = 
            chPermiteEstoqueNegativo.Checked = false;
        }

        private void Gravar()
        {
            string sql = @"INSERT INTO produto (descricao,valor_venda,estoque_atual,estoque_minimo,codigo_barra,unidade,ativo,controla_estoque,permite_estoque_negativo,grupo,fornecedor)
                               VALUES(@descricao,@valor_venda,@estoque_atual,@estoque_minimo,@codigo_barra,@unidade,@ativo,@controla_estoque,@permite_estoque_negativo,@grupo,@fornecedor)";
            var conexao = new Conexao.Conexao();
            SqlCommand cmd = new SqlCommand(sql, conexao.conn);

            try
            {
                cmd.Parameters.AddWithValue("@descricao", tbDescricao.Text.ToUpper());
                cmd.Parameters.AddWithValue("@valor_venda", decimal.Parse(tbValorVenda.Text));
                cmd.Parameters.AddWithValue("@estoque_atual", int.Parse(tbEstoque.Text == "" ? "0" : tbEstoque.Text));
                cmd.Parameters.AddWithValue("@estoque_minimo", int.Parse(tbEstoqueMinimo.Text == "" ? "0" : tbEstoqueMinimo.Text));
                cmd.Parameters.AddWithValue("@codigo_barra", tbCodigoBarra.Text);
                cmd.Parameters.AddWithValue("@ativo", rbAtivo.Checked ? 1 : 0);
                cmd.Parameters.AddWithValue("@unidade", cbUnidade.Text);
                cmd.Parameters.AddWithValue("@controla_estoque", chControlaEstoque.Checked);
                cmd.Parameters.AddWithValue("@permite_estoque_negativo", chPermiteEstoqueNegativo.Checked);
                cmd.Parameters.AddWithValue("@grupo", cbGrupo.SelectedIndex == null ? 0 : cbGrupo.SelectedIndex);
                cmd.Parameters.AddWithValue("@fornecedor", cbFornecedor.SelectedIndex == null ? 0: cbGrupo.SelectedIndex);

                conexao.AbrirConexao();

                cmd.ExecuteNonQuery();
                MessageBox.Show("Gravado com sucesso !", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro," + ex, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conexao.FecharConexao();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //btnExcluir
        }

        private void CadProduto_Load(object sender, EventArgs e)
        {
            tbDescricao.Select();
        }
    }
}
