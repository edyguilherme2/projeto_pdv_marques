﻿using Forms.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Forms.Views
{
    public partial class ConsultaProdutos : Form
    {
        public int id;
        public string desc;
        public string valor;
        public string estoque;
        public string status; 
        public Produto produto = new Produto();

        public ConsultaProdutos()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            Carregar(tbDescricao.Text);
        }

        private void ConsultaProdutos_Load(object sender, EventArgs e)
        {
            tbDescricao.Select();
            Carregar();
        }

        private void Carregar(string pesquisa = "")
        {
            listView1.Items.Clear();
            List<Produto> lista = Produto.Carrega(pesquisa);
            foreach (var item in lista)
            {
                var lvw = new ListViewItem();
                var descricao = new ListViewItem.ListViewSubItem();
                var valor_venda = new ListViewItem.ListViewSubItem();
                var estoque_atual = new ListViewItem.ListViewSubItem();
                var estoque_minimo = new ListViewItem.ListViewSubItem();
                var unidade = new ListViewItem.ListViewSubItem();
                var status = new ListViewItem.ListViewSubItem();

                string ativo = item.ativo == 1 ? "ATIVO": "INATIVO";
                
                lvw.Text = $"{item.id_produto:D4}";
                descricao.Text = item.descricao;
                valor_venda.Text = decimal.Parse(item.valor_venda).ToString("n");
                estoque_atual.Text = item.estoque_atual;
                estoque_minimo.Text = item.estoque_minimo;
                unidade.Text = item.unidade;
                unidade.Text = item.unidade;
                status.Text = ativo;

                lvw.SubItems.Add(descricao);
                lvw.SubItems.Add(valor_venda);
                lvw.SubItems.Add(estoque_atual);
                lvw.SubItems.Add(estoque_minimo);
                lvw.SubItems.Add(unidade);
                lvw.SubItems.Add(status);

                listView1.Items.Add(lvw);

                PintarLinhaLvw(ref listView1);
            }
        }

        private void PintarLinhaLvw(ref ListView lv)
        {
            if (lv.Items.Count > 0)
                if ((lv.Items.Count - 1) % 2 == 0)
                    lv.Items[lv.Items.Count - 1].BackColor = Color.FromArgb(238, 238, 238);
        }

        private void tbDescricao_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                Carregar(tbDescricao.Text);
            }
            else if(e.KeyCode == Keys.Escape)
                Close();
        }


        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            //MessageBox.Show("teste");
            if (listView1.SelectedItems.Count > 0)
            {
                produto.id_produto = int.Parse(listView1.SelectedItems[0].Text);
                //id = int.Parse(listView1.SelectedItems[0].Text);
                produto.descricao = listView1.SelectedItems[0].SubItems[1].Text;
                produto.valor_venda = listView1.SelectedItems[0].SubItems[2].Text;
                produto.estoque_atual = listView1.SelectedItems[0].SubItems[3].Text;
                Close();
            }
        }
    }
}
